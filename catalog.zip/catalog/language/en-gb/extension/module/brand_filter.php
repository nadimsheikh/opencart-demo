<?php

$_['heading_title'] = 'Filter by brand';
$_['button_filter'] = 'Filter';
