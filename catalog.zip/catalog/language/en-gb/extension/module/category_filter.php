<?php

$_['heading_title'] = 'Filter by category';
$_['button_filter'] = 'Filter';
