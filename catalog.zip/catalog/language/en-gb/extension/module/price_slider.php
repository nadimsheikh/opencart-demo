<?php
/*
  Module Name: Magic Filter
  Description:MagicFilter plugin is one of the best product filter plugin for opencart. It has feature to filter products by
  manufactures and price range.
  Author: Rootingenious infotch
  Author Email:support@rootingenious.com
  Author URI: www.rootingenious.com
  Version: 1.0
  Tags: filter, magic filter, price filter, manufacture filter, brand filter,product filter
 */
// Heading
$_['heading_title'] = 'Filter by Price';
$_['button_filter'] = 'Filter';
