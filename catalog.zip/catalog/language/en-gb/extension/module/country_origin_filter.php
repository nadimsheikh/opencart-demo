<?php

$_['heading_title'] = 'Filter by country origin';
$_['button_filter'] = 'Filter';
