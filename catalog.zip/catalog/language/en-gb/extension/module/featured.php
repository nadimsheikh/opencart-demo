<?php

// Heading
$_['heading_title'] = 'Top Products';

// Text
$_['text_tax'] = 'Ex Tax:';
