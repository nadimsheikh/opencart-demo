<?php
// Text
$_['text_all'] = 'Show All';
$_['text_all_products'] = 'All Products';