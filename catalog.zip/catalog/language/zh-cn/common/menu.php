<?php
// Text
$_['text_all'] = '显示所有';