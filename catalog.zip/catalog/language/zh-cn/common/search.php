<?php
// Text
$_['text_search'] = '搜索';