<?php
// Text
$_['text_success']     = '成功: 已使用折扣券！';

// Error
$_['error_permission'] = '警告: 无权限方位 API 接口！';
$_['error_coupon']     = '警告: 折扣券无效、过期或已达到使用次数上限！';