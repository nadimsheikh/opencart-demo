<?php
// Text
$_['text_success']     = '成功: 已转换货币！';

// Error
$_['error_permission'] = '警告: 无权限访问该API！';
$_['error_currency']   = '警告: 货币代码无效！';