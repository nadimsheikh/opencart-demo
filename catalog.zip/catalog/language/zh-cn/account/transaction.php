<?php
// Heading
$_['heading_title']      = '账户余额';

// Column
$_['column_date_added']  = '添加日期';
$_['column_description'] = '描述';
$_['column_amount']      = '金额 (%s)';

// Text
$_['text_account']       = '账户';
$_['text_transaction']   = '账户余额记录';
$_['text_total']         = '账户余额为:';
$_['text_empty']         = '您还没有任何账户余额记录！';