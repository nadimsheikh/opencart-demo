<?php
// Heading
$_['heading_title']      = '奖励积分';

// Column
$_['column_date_added']  = '添加日期';
$_['column_description'] = '描述';
$_['column_points']      = '积分';

// Text
$_['text_account']       = '账户';
$_['text_reward']        = '奖励积分';
$_['text_total']         = '奖励积分总数为:';
$_['text_empty']         = '还没有获取过奖励积分!';