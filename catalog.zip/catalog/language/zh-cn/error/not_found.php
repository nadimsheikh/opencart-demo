<?php
// Heading
$_['heading_title'] = '您查询的页面不存在！';

// Text
$_['text_error']    = '您查询的页面不存在。';