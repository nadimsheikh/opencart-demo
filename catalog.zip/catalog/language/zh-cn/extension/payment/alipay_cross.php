<?php
// Text
$_['text_title'] = '支付宝跨境支付';
