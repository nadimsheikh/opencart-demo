<?php

// Text
$_['text_title'] = '免费结帐';