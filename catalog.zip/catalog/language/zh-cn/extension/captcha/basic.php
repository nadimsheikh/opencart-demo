<?php
// Text
$_['text_captcha']  = '验证码';

// Entry
$_['entry_captcha'] = '输入下图验证码';

// Error
$_['error_captcha'] = '验证码不正确！';
