<?php
// Heading
$_['heading_title'] = '商品分类';